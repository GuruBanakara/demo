package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.service.EmployeeService;
import com.example.demo.service.StudentService;

@RestController
public class PersonController {

	@Autowired
	private EmployeeService employeeService;
	@Autowired
	private StudentService studentService;

	@GetMapping("save")
	public void saveAll() {
		employeeService.saveAll();
	}

	@GetMapping("ss")
	public void saveStudent() {
		studentService.saveStudent();
	}

}
