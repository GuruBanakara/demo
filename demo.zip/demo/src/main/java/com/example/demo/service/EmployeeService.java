package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Employee;
import com.example.demo.repo.EmployeeRepository;

@Service
@Transactional("ds1TransactionManager")
public class EmployeeService {

	@Autowired(required = false)
	private EmployeeRepository employeeRepository;

	public void saveAll() {
		List<Employee> employees = new ArrayList<>();
		Employee e1 = new Employee();
		e1.setName("Employee1");
		Employee e2 = new Employee();
		e2.setName("Employee2");
		Employee e3 = new Employee();
		e3.setName("Employee3");
		Employee e4 = new Employee();
		e4.setName("Employee4");
		employees.add(e2);
		employees.add(e1);
		employees.add(e4);
		employees.add(e3);
		employeeRepository.saveAll(employees);
	}

}
