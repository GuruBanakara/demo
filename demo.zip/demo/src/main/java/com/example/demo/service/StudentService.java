package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.model.Student;
import com.example.demo.repo.StudentRepository;

@Service
@Transactional("ds2TransactionManager")
public class StudentService {
	@Autowired(required = false)
	private StudentRepository studentRepository;

	public void saveStudent() {
		studentRepository.save(new Student("Student 1"));
	}

}
